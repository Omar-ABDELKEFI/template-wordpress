jQuery(document).ready(function($) {
    $('.song-form').on('submit', function(e) {
        e.preventDefault();  // Prevent default form submission

        const songUrl = $('#songUrl').val().trim();
        const songFile = $('#songFile')[0].files[0];
        
        // Ensure either URL or File is provided, but not both
        if ((songUrl && songFile) || (!songUrl && !songFile)) {
            alert('Please provide either a song URL or upload an MP3 file, but not both.');
            return;
        }

        const form = $(this)[0];
        const formData = new FormData(form);  // Create FormData object for file uploads
        
        // Check if MP3 file is present and append it to FormData
        if (songFile) {
            formData.append('songFile', songFile);
        }

        const submitButton = $(this).find('button[type="submit"]');
        submitButton.css('background-color', '#c36');
        submitButton.css('transform', 'translateY(-2px)');

        // Show spinner
        $('.spinner').show();
        $('.results').remove(); // Remove previous results if any

        // Send the form data with the MP3 file (if uploaded) or URL
        $.ajax({
            url: songSimilarity.api_url,  // Use the API URL passed from PHP
            type: 'POST',
            processData: false,  // Important for file upload
            contentType: false,  // Important for file upload
            data: formData,  // Send the form data
            success: function(response) {
                $('.spinner').hide();  // Hide the spinner when response is received
                submitButton.css('background-color', '#2ecc71');  // Reset button color

                if (response && Array.isArray(response)) {
                    let resultsHtml = '<div class="results"><h2>Comparison Results:</h2><table><thead><tr><th>Artist Song</th><th>Similarity</th></tr></thead><tbody>';
                    response.forEach(result => {
                        resultsHtml += `<tr><td>${result.artist_song}</td><td>${result.similarity.toFixed(2)}</td></tr>`;
                    });
                    resultsHtml += '</tbody></table></div>';
                    $('.song-form').after(resultsHtml);  // Display the results
                } else {
                    alert('Unexpected response from the server.');
                }
            },
            error: function(e) {
                $('.spinner').hide();
                submitButton.css('background-color', '#2ecc71');  // Reset button color on error
                alert('An error occurred: ' + e.responseJSON.error);
            }
        });
    });
});
