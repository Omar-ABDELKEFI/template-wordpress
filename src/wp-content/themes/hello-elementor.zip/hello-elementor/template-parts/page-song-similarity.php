<?php
/**
 * Template Name: Song Similarity Form
 */
get_header();
?>


    <div class="song-form-container">
        <h1 class="h1-class">Song Similarity Finder</h1>
        <p class="description">
            Discover how your favorite song compares to the top hits of any artist. Simply enter the details below, and we'll analyze the similarity, giving you a unique insight into musical patterns and styles.
        </p>
        <form class="song-form" enctype="multipart/form-data">
    <div class="form-row">
        <div class="form-group">
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" name="firstName" required />
        </div>
        <div class="form-group">
            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" name="lastName" required />
        </div>
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required />
    </div>
    <div class="form-group">
        <label for="songUrl">Your Song URL</label>
        <input type="url" id="songUrl" name="songUrl" />
    </div>
    <div class="form-group">
        <label for="songFile">Upload Your MP3 File</label>
        <input type="file" id="songFile" name="songFile" accept="audio/mp3" />
    </div>
    <div class="form-group">
        <label for="lyrics">Lyrics</label>
        <textarea class="textarea-class" id="lyrics" name="lyrics" required></textarea>
    </div>
    <div class="form-group">
        <label for="singer">Artist to Compare</label>
        <input type="text" id="singer" name="singer" required />
    </div>
    <button type="submit" class="submit-btn">Analyze Similarity</button>
</form>

        <div class="spinner" style="display: none;">
            <div class="spinner-border"></div>
            <p>Generating Song Similarity Score...</p>
        </div>
    </div>


<?php get_footer(); ?>